﻿
namespace Project_9
{
    partial class spaceVoyagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(spaceVoyagerForm));
            this.labelTitle = new System.Windows.Forms.Label();
            this.marvinPictureBox = new System.Windows.Forms.PictureBox();
            this.marvinItemBox = new System.Windows.Forms.ListBox();
            this.planetsItemBox = new System.Windows.Forms.ListBox();
            this.planetOne = new System.Windows.Forms.PictureBox();
            this.fivePlanetPicBox = new System.Windows.Forms.PictureBox();
            this.planetTwo = new System.Windows.Forms.PictureBox();
            this.planetThree = new System.Windows.Forms.PictureBox();
            this.planetFour = new System.Windows.Forms.PictureBox();
            this.planetFive = new System.Windows.Forms.PictureBox();
            this.tradeButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.marvinPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetOne)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePlanetPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetTwo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetThree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetFour)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetFive)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelTitle.Font = new System.Drawing.Font("Snap ITC", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelTitle.Location = new System.Drawing.Point(21, 41);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(352, 51);
            this.labelTitle.TabIndex = 1;
            this.labelTitle.Text = "Space Voyager";
            // 
            // marvinPictureBox
            // 
            this.marvinPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.marvinPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("marvinPictureBox.BackgroundImage")));
            this.marvinPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("marvinPictureBox.Image")));
            this.marvinPictureBox.Location = new System.Drawing.Point(1081, 28);
            this.marvinPictureBox.Name = "marvinPictureBox";
            this.marvinPictureBox.Size = new System.Drawing.Size(174, 114);
            this.marvinPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.marvinPictureBox.TabIndex = 2;
            this.marvinPictureBox.TabStop = false;
            // 
            // marvinItemBox
            // 
            this.marvinItemBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.marvinItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marvinItemBox.FormattingEnabled = true;
            this.marvinItemBox.ItemHeight = 18;
            this.marvinItemBox.Location = new System.Drawing.Point(394, 560);
            this.marvinItemBox.Name = "marvinItemBox";
            this.marvinItemBox.Size = new System.Drawing.Size(230, 94);
            this.marvinItemBox.TabIndex = 4;
            // 
            // planetsItemBox
            // 
            this.planetsItemBox.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.planetsItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.planetsItemBox.FormattingEnabled = true;
            this.planetsItemBox.ItemHeight = 18;
            this.planetsItemBox.Location = new System.Drawing.Point(685, 560);
            this.planetsItemBox.Name = "planetsItemBox";
            this.planetsItemBox.Size = new System.Drawing.Size(230, 94);
            this.planetsItemBox.TabIndex = 5;
            // 
            // planetOne
            // 
            this.planetOne.BackColor = System.Drawing.Color.Black;
            this.planetOne.Image = ((System.Drawing.Image)(resources.GetObject("planetOne.Image")));
            this.planetOne.Location = new System.Drawing.Point(187, 334);
            this.planetOne.Name = "planetOne";
            this.planetOne.Size = new System.Drawing.Size(93, 67);
            this.planetOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.planetOne.TabIndex = 6;
            this.planetOne.TabStop = false;
            // 
            // fivePlanetPicBox
            // 
            this.fivePlanetPicBox.Image = ((System.Drawing.Image)(resources.GetObject("fivePlanetPicBox.Image")));
            this.fivePlanetPicBox.Location = new System.Drawing.Point(1, 1);
            this.fivePlanetPicBox.Name = "fivePlanetPicBox";
            this.fivePlanetPicBox.Size = new System.Drawing.Size(1280, 727);
            this.fivePlanetPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fivePlanetPicBox.TabIndex = 7;
            this.fivePlanetPicBox.TabStop = false;
            // 
            // planetTwo
            // 
            this.planetTwo.BackColor = System.Drawing.Color.Transparent;
            this.planetTwo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("planetTwo.BackgroundImage")));
            this.planetTwo.Image = ((System.Drawing.Image)(resources.GetObject("planetTwo.Image")));
            this.planetTwo.Location = new System.Drawing.Point(352, 160);
            this.planetTwo.Name = "planetTwo";
            this.planetTwo.Size = new System.Drawing.Size(98, 64);
            this.planetTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.planetTwo.TabIndex = 8;
            this.planetTwo.TabStop = false;
            // 
            // planetThree
            // 
            this.planetThree.BackColor = System.Drawing.Color.Transparent;
            this.planetThree.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("planetThree.BackgroundImage")));
            this.planetThree.Image = ((System.Drawing.Image)(resources.GetObject("planetThree.Image")));
            this.planetThree.Location = new System.Drawing.Point(591, 28);
            this.planetThree.Name = "planetThree";
            this.planetThree.Size = new System.Drawing.Size(103, 74);
            this.planetThree.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.planetThree.TabIndex = 9;
            this.planetThree.TabStop = false;
            // 
            // planetFour
            // 
            this.planetFour.BackColor = System.Drawing.Color.Transparent;
            this.planetFour.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("planetFour.BackgroundImage")));
            this.planetFour.Image = ((System.Drawing.Image)(resources.GetObject("planetFour.Image")));
            this.planetFour.Location = new System.Drawing.Point(906, 232);
            this.planetFour.Name = "planetFour";
            this.planetFour.Size = new System.Drawing.Size(103, 74);
            this.planetFour.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.planetFour.TabIndex = 10;
            this.planetFour.TabStop = false;
            // 
            // planetFive
            // 
            this.planetFive.BackColor = System.Drawing.Color.Transparent;
            this.planetFive.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("planetFive.BackgroundImage")));
            this.planetFive.Image = ((System.Drawing.Image)(resources.GetObject("planetFive.Image")));
            this.planetFive.Location = new System.Drawing.Point(1060, 370);
            this.planetFive.Name = "planetFive";
            this.planetFive.Size = new System.Drawing.Size(103, 74);
            this.planetFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.planetFive.TabIndex = 11;
            this.planetFive.TabStop = false;
            // 
            // tradeButton
            // 
            this.tradeButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tradeButton.Font = new System.Drawing.Font("Snap ITC", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradeButton.Location = new System.Drawing.Point(12, 494);
            this.tradeButton.Name = "tradeButton";
            this.tradeButton.Size = new System.Drawing.Size(124, 49);
            this.tradeButton.TabIndex = 12;
            this.tradeButton.Text = "Trade";
            this.tradeButton.UseVisualStyleBackColor = false;
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.clearButton.Font = new System.Drawing.Font("Snap ITC", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(12, 560);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(124, 49);
            this.clearButton.TabIndex = 13;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.exitButton.Font = new System.Drawing.Font("Snap ITC", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(12, 623);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(124, 49);
            this.exitButton.TabIndex = 14;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            // 
            // spaceVoyagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1278, 684);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.tradeButton);
            this.Controls.Add(this.planetFive);
            this.Controls.Add(this.planetFour);
            this.Controls.Add(this.planetThree);
            this.Controls.Add(this.planetTwo);
            this.Controls.Add(this.planetOne);
            this.Controls.Add(this.planetsItemBox);
            this.Controls.Add(this.marvinItemBox);
            this.Controls.Add(this.marvinPictureBox);
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.fivePlanetPicBox);
            this.Name = "spaceVoyagerForm";
            this.Text = "Space Voyager";
            ((System.ComponentModel.ISupportInitialize)(this.marvinPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetOne)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fivePlanetPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetTwo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetThree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetFour)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planetFive)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.PictureBox marvinPictureBox;
        private System.Windows.Forms.ListBox marvinItemBox;
        private System.Windows.Forms.ListBox planetsItemBox;
        private System.Windows.Forms.PictureBox planetOne;
        private System.Windows.Forms.PictureBox fivePlanetPicBox;
        private System.Windows.Forms.PictureBox planetTwo;
        private System.Windows.Forms.PictureBox planetThree;
        private System.Windows.Forms.PictureBox planetFour;
        private System.Windows.Forms.PictureBox planetFive;
        private System.Windows.Forms.Button tradeButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

