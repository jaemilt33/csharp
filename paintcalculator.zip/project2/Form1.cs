﻿/* Jelecia Milton
    
   * COP2551
  
   * 9/6/2021
   
   * This form allows the user to input square footage to be painted and cost per gallon
   * of paint. Then it displays the gallons of paint required, hours of labor required, cost of paint
   * required, cost of labor required, and the total cost of the job. */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project2
{
    public partial class paintJobEstimator : Form
    {
        public paintJobEstimator()
        {
            InitializeComponent();
        }

        //Constants declared
        const decimal HOURLY_RATE = 20.00m;
        const decimal SQUARE_FOOTAGE = 115;
        const decimal LABOR_HOURS = 8;

        private void calculateGallonsButton_Click(object sender, EventArgs e)
        {
            try { 

                //Variables declared
                decimal userSquareFootage;
                decimal paintNeeded;
                decimal hoursOfLabor;
                decimal costOfPaintRequired;
                decimal costOfLabor;
                decimal totalCost;
                decimal costPerGallon;

                //Parse the input value
                userSquareFootage = decimal.Parse(squareFootageTextBox.Text);
                costPerGallon = decimal.Parse(costGallonTextBox.Text);

                //Calculate the amount of paint needed, cost of paint required
                //hours of labor, cost of labor and total cost
                paintNeeded = userSquareFootage / SQUARE_FOOTAGE;
                costOfPaintRequired = paintNeeded * costPerGallon;
                hoursOfLabor = LABOR_HOURS * paintNeeded;
                costOfLabor = hoursOfLabor * HOURLY_RATE;
                totalCost = costOfLabor + costOfPaintRequired;

                //Display output with calculate button or ALT+a
                this.gallonOfPaintRequiredLabel.Text = paintNeeded.ToString("f");
                this.hoursOfLaborRequiredLabel.Text = hoursOfLabor.ToString("f");
                this.costOfPaintRequiredLabel.Text = costOfPaintRequired.ToString("c");
                this.costOfLaborRequiredLabel.Text = costOfLabor.ToString("c");
                this.totalCostOfJobLabel.Text = totalCost.ToString("c");
            }
            catch(Exception ex)
            {
                //Display error box
                MessageBox.Show("Invalid data was entered.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears all information from textboxes and labels with the clear button
            //or ALT+c
            squareFootageTextBox.Clear();
            costGallonTextBox.Clear();
            gallonOfPaintRequiredLabel.Text = "";
            hoursOfLaborRequiredLabel.Text = "";
            costOfPaintRequiredLabel.Text = "";
            costOfLaborRequiredLabel.Text = "";
            totalCostOfJobLabel.Text = "";

            //Focuses on square footage textbox once everything is cleared
            squareFootageTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //CLose the program with the exit button or ALT+x
            this.Close();
        }
    }
}
