﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_9
{
    public partial class spaceVoyagerForm : Form
    {
        public spaceVoyagerForm()
        {
            InitializeComponent();

            showPlanetOne();
        }

        public void showPlanetOne()
        {
            planetOne.Visible = true;
            planetTwo.Visible = false;
            planetThree.Visible = false;
            planetFour.Visible = false;
            planetFive.Visible = false;
        }

        public void showPlanetTwo()
        {
            planetOne.Visible = false;
            planetTwo.Visible = true;
            planetThree.Visible = false;
            planetFour.Visible = false;
            planetFive.Visible = false;
        }

        public void showPlanetThree()
        {
            planetOne.Visible = false;
            planetTwo.Visible = false;
            planetThree.Visible = true;
            planetFour.Visible = false;
            planetFive.Visible = false;
        }

        public void showPlanetFour()
        {
            planetOne.Visible = false;
            planetTwo.Visible = false;
            planetThree.Visible = false;
            planetFour.Visible = true;
            planetFive.Visible = false;
        }

        public void showPlanetFive()
        {
            planetOne.Visible = false;
            planetTwo.Visible = false;
            planetThree.Visible = false;
            planetFour.Visible = false;
            planetFive.Visible = true;
        }
    }
}
