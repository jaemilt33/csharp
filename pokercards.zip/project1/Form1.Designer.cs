﻿
namespace project1
{
    partial class cardIdentifier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cardIdentifier));
            this.sevenOfDiamonds = new System.Windows.Forms.PictureBox();
            this.queenOfClubs = new System.Windows.Forms.PictureBox();
            this.redJoker = new System.Windows.Forms.PictureBox();
            this.eightOfSpades = new System.Windows.Forms.PictureBox();
            this.aceOfHearts = new System.Windows.Forms.PictureBox();
            this.cardIdentifierInstructions = new System.Windows.Forms.Label();
            this.cardChosenLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.sevenOfDiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenOfClubs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.redJoker)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightOfSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfHearts)).BeginInit();
            this.SuspendLayout();
            // 
            // sevenOfDiamonds
            // 
            this.sevenOfDiamonds.Image = ((System.Drawing.Image)(resources.GetObject("sevenOfDiamonds.Image")));
            this.sevenOfDiamonds.Location = new System.Drawing.Point(62, 96);
            this.sevenOfDiamonds.Name = "sevenOfDiamonds";
            this.sevenOfDiamonds.Size = new System.Drawing.Size(79, 118);
            this.sevenOfDiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sevenOfDiamonds.TabIndex = 0;
            this.sevenOfDiamonds.TabStop = false;
            this.sevenOfDiamonds.Click += new System.EventHandler(this.sevenOfDiamonds_Click);
            // 
            // queenOfClubs
            // 
            this.queenOfClubs.Image = ((System.Drawing.Image)(resources.GetObject("queenOfClubs.Image")));
            this.queenOfClubs.Location = new System.Drawing.Point(182, 96);
            this.queenOfClubs.Name = "queenOfClubs";
            this.queenOfClubs.Size = new System.Drawing.Size(79, 118);
            this.queenOfClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenOfClubs.TabIndex = 1;
            this.queenOfClubs.TabStop = false;
            this.queenOfClubs.Click += new System.EventHandler(this.queenOfClubs_Click);
            // 
            // redJoker
            // 
            this.redJoker.Image = ((System.Drawing.Image)(resources.GetObject("redJoker.Image")));
            this.redJoker.Location = new System.Drawing.Point(307, 96);
            this.redJoker.Name = "redJoker";
            this.redJoker.Size = new System.Drawing.Size(79, 118);
            this.redJoker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.redJoker.TabIndex = 2;
            this.redJoker.TabStop = false;
            this.redJoker.Click += new System.EventHandler(this.redJoker_Click);
            // 
            // eightOfSpades
            // 
            this.eightOfSpades.Image = ((System.Drawing.Image)(resources.GetObject("eightOfSpades.Image")));
            this.eightOfSpades.Location = new System.Drawing.Point(430, 96);
            this.eightOfSpades.Name = "eightOfSpades";
            this.eightOfSpades.Size = new System.Drawing.Size(79, 118);
            this.eightOfSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eightOfSpades.TabIndex = 3;
            this.eightOfSpades.TabStop = false;
            this.eightOfSpades.Click += new System.EventHandler(this.eightOfSpades_Click);
            // 
            // aceOfHearts
            // 
            this.aceOfHearts.Image = ((System.Drawing.Image)(resources.GetObject("aceOfHearts.Image")));
            this.aceOfHearts.Location = new System.Drawing.Point(567, 96);
            this.aceOfHearts.Name = "aceOfHearts";
            this.aceOfHearts.Size = new System.Drawing.Size(79, 118);
            this.aceOfHearts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceOfHearts.TabIndex = 4;
            this.aceOfHearts.TabStop = false;
            this.aceOfHearts.Click += new System.EventHandler(this.aceOfHearts_Click);
            // 
            // cardIdentifierInstructions
            // 
            this.cardIdentifierInstructions.Font = new System.Drawing.Font("Modern No. 20", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardIdentifierInstructions.Location = new System.Drawing.Point(132, 19);
            this.cardIdentifierInstructions.Name = "cardIdentifierInstructions";
            this.cardIdentifierInstructions.Size = new System.Drawing.Size(447, 58);
            this.cardIdentifierInstructions.TabIndex = 5;
            this.cardIdentifierInstructions.Text = "Click a Card to See Its Name.";
            this.cardIdentifierInstructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cardChosenLabel
            // 
            this.cardChosenLabel.BackColor = System.Drawing.SystemColors.Control;
            this.cardChosenLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardChosenLabel.Font = new System.Drawing.Font("Modern No. 20", 16.2F, System.Drawing.FontStyle.Bold);
            this.cardChosenLabel.ForeColor = System.Drawing.Color.Red;
            this.cardChosenLabel.Location = new System.Drawing.Point(62, 262);
            this.cardChosenLabel.Name = "cardChosenLabel";
            this.cardChosenLabel.Size = new System.Drawing.Size(584, 66);
            this.cardChosenLabel.TabIndex = 6;
            this.cardChosenLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(269, 363);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(161, 47);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // cardIdentifier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(722, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cardChosenLabel);
            this.Controls.Add(this.cardIdentifierInstructions);
            this.Controls.Add(this.aceOfHearts);
            this.Controls.Add(this.eightOfSpades);
            this.Controls.Add(this.redJoker);
            this.Controls.Add(this.queenOfClubs);
            this.Controls.Add(this.sevenOfDiamonds);
            this.Name = "cardIdentifier";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.sevenOfDiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenOfClubs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.redJoker)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eightOfSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aceOfHearts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox sevenOfDiamonds;
        private System.Windows.Forms.PictureBox queenOfClubs;
        private System.Windows.Forms.PictureBox redJoker;
        private System.Windows.Forms.PictureBox eightOfSpades;
        private System.Windows.Forms.PictureBox aceOfHearts;
        private System.Windows.Forms.Label cardIdentifierInstructions;
        private System.Windows.Forms.Label cardChosenLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

