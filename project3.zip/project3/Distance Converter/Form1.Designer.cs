﻿
namespace Distance_Converter
{
    partial class distanceConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(distanceConverter));
            this.enterLabel = new System.Windows.Forms.Label();
            this.enterTextBox = new System.Windows.Forms.TextBox();
            this.fromListBox = new System.Windows.Forms.ListBox();
            this.toListBox = new System.Windows.Forms.ListBox();
            this.fromLabel = new System.Windows.Forms.Label();
            this.toLabel = new System.Windows.Forms.Label();
            this.convertedLabel = new System.Windows.Forms.Label();
            this.convertButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.conversionLabel = new System.Windows.Forms.Label();
            this.roadPictureBox = new System.Windows.Forms.PictureBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.distanceConversionCalcLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.roadPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // enterLabel
            // 
            this.enterLabel.AutoSize = true;
            this.enterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterLabel.Location = new System.Drawing.Point(7, 118);
            this.enterLabel.Name = "enterLabel";
            this.enterLabel.Size = new System.Drawing.Size(248, 25);
            this.enterLabel.TabIndex = 0;
            this.enterLabel.Text = "Enter a distance to convert:";
            this.enterLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // enterTextBox
            // 
            this.enterTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterTextBox.Location = new System.Drawing.Point(287, 113);
            this.enterTextBox.Name = "enterTextBox";
            this.enterTextBox.Size = new System.Drawing.Size(188, 30);
            this.enterTextBox.TabIndex = 0;
            // 
            // fromListBox
            // 
            this.fromListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromListBox.FormattingEnabled = true;
            this.fromListBox.ItemHeight = 25;
            this.fromListBox.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.fromListBox.Location = new System.Drawing.Point(87, 215);
            this.fromListBox.Name = "fromListBox";
            this.fromListBox.Size = new System.Drawing.Size(99, 79);
            this.fromListBox.TabIndex = 1;
            this.fromListBox.Tag = "";
            // 
            // toListBox
            // 
            this.toListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toListBox.FormattingEnabled = true;
            this.toListBox.ItemHeight = 25;
            this.toListBox.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.toListBox.Location = new System.Drawing.Point(323, 215);
            this.toListBox.Name = "toListBox";
            this.toListBox.Size = new System.Drawing.Size(99, 79);
            this.toListBox.TabIndex = 2;
            // 
            // fromLabel
            // 
            this.fromLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fromLabel.Location = new System.Drawing.Point(61, 193);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(149, 125);
            this.fromLabel.TabIndex = 4;
            this.fromLabel.Text = "From";
            // 
            // toLabel
            // 
            this.toLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toLabel.Location = new System.Drawing.Point(287, 193);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(149, 125);
            this.toLabel.TabIndex = 5;
            this.toLabel.Text = "To";
            // 
            // convertedLabel
            // 
            this.convertedLabel.AutoSize = true;
            this.convertedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertedLabel.Location = new System.Drawing.Point(34, 356);
            this.convertedLabel.Name = "convertedLabel";
            this.convertedLabel.Size = new System.Drawing.Size(187, 25);
            this.convertedLabel.TabIndex = 6;
            this.convertedLabel.Text = "Converted distance:";
            this.convertedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // convertButton
            // 
            this.convertButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convertButton.Location = new System.Drawing.Point(61, 421);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(103, 54);
            this.convertButton.TabIndex = 3;
            this.convertButton.Text = "&Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(368, 421);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(103, 54);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // conversionLabel
            // 
            this.conversionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.conversionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conversionLabel.Location = new System.Drawing.Point(283, 356);
            this.conversionLabel.Name = "conversionLabel";
            this.conversionLabel.Size = new System.Drawing.Size(188, 30);
            this.conversionLabel.TabIndex = 10;
            this.conversionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // roadPictureBox
            // 
            this.roadPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("roadPictureBox.Image")));
            this.roadPictureBox.Location = new System.Drawing.Point(12, 340);
            this.roadPictureBox.Name = "roadPictureBox";
            this.roadPictureBox.Size = new System.Drawing.Size(335, 208);
            this.roadPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.roadPictureBox.TabIndex = 11;
            this.roadPictureBox.TabStop = false;
            // 
            // clearButton
            // 
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(218, 421);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(103, 54);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "C&lear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // distanceConversionCalcLabel
            // 
            this.distanceConversionCalcLabel.AutoSize = true;
            this.distanceConversionCalcLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distanceConversionCalcLabel.Location = new System.Drawing.Point(104, 41);
            this.distanceConversionCalcLabel.Name = "distanceConversionCalcLabel";
            this.distanceConversionCalcLabel.Size = new System.Drawing.Size(286, 25);
            this.distanceConversionCalcLabel.TabIndex = 12;
            this.distanceConversionCalcLabel.Text = "Distance Conversion Calculator";
            this.distanceConversionCalcLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // distanceConverter
            // 
            this.AcceptButton = this.convertButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(498, 547);
            this.Controls.Add(this.distanceConversionCalcLabel);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.conversionLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.convertedLabel);
            this.Controls.Add(this.toListBox);
            this.Controls.Add(this.fromListBox);
            this.Controls.Add(this.enterTextBox);
            this.Controls.Add(this.enterLabel);
            this.Controls.Add(this.fromLabel);
            this.Controls.Add(this.toLabel);
            this.Controls.Add(this.roadPictureBox);
            this.Name = "distanceConverter";
            this.Text = "Distance Converter";
            ((System.ComponentModel.ISupportInitialize)(this.roadPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterLabel;
        private System.Windows.Forms.TextBox enterTextBox;
        private System.Windows.Forms.ListBox fromListBox;
        private System.Windows.Forms.ListBox toListBox;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.Label convertedLabel;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label conversionLabel;
        private System.Windows.Forms.PictureBox roadPictureBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Label distanceConversionCalcLabel;
    }
}

