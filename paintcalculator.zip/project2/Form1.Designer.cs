﻿
namespace project2
{
    partial class paintJobEstimator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(paintJobEstimator));
            this.squareFootagePromptLabel = new System.Windows.Forms.Label();
            this.costGallonPromptLabel = new System.Windows.Forms.Label();
            this.squareFootageTextBox = new System.Windows.Forms.TextBox();
            this.costGallonTextBox = new System.Windows.Forms.TextBox();
            this.calculateGallonsButton = new System.Windows.Forms.Button();
            this.gallonOfPaintLabel = new System.Windows.Forms.Label();
            this.costOfPaintLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborLabel = new System.Windows.Forms.Label();
            this.costOfLaborLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.paintJobEstimatorLabel = new System.Windows.Forms.Label();
            this.gallonOfPaintRequiredLabel = new System.Windows.Forms.Label();
            this.hoursOfLaborRequiredLabel = new System.Windows.Forms.Label();
            this.costOfPaintRequiredLabel = new System.Windows.Forms.Label();
            this.costOfLaborRequiredLabel = new System.Windows.Forms.Label();
            this.totalCostOfJobLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // squareFootagePromptLabel
            // 
            this.squareFootagePromptLabel.AutoSize = true;
            this.squareFootagePromptLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.squareFootagePromptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squareFootagePromptLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.squareFootagePromptLabel.Location = new System.Drawing.Point(33, 127);
            this.squareFootagePromptLabel.Name = "squareFootagePromptLabel";
            this.squareFootagePromptLabel.Size = new System.Drawing.Size(399, 20);
            this.squareFootagePromptLabel.TabIndex = 5;
            this.squareFootagePromptLabel.Text = "Please enter the square footage to be painted:";
            // 
            // costGallonPromptLabel
            // 
            this.costGallonPromptLabel.AutoSize = true;
            this.costGallonPromptLabel.BackColor = System.Drawing.SystemColors.Highlight;
            this.costGallonPromptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costGallonPromptLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.costGallonPromptLabel.Location = new System.Drawing.Point(559, 127);
            this.costGallonPromptLabel.Name = "costGallonPromptLabel";
            this.costGallonPromptLabel.Size = new System.Drawing.Size(353, 20);
            this.costGallonPromptLabel.TabIndex = 6;
            this.costGallonPromptLabel.Text = "Please enter the cost per gallon of paint:";
            // 
            // squareFootageTextBox
            // 
            this.squareFootageTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.squareFootageTextBox.Location = new System.Drawing.Point(156, 170);
            this.squareFootageTextBox.Name = "squareFootageTextBox";
            this.squareFootageTextBox.Size = new System.Drawing.Size(145, 27);
            this.squareFootageTextBox.TabIndex = 0;
            // 
            // costGallonTextBox
            // 
            this.costGallonTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costGallonTextBox.Location = new System.Drawing.Point(676, 170);
            this.costGallonTextBox.Name = "costGallonTextBox";
            this.costGallonTextBox.Size = new System.Drawing.Size(145, 27);
            this.costGallonTextBox.TabIndex = 1;
            // 
            // calculateGallonsButton
            // 
            this.calculateGallonsButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.calculateGallonsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateGallonsButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.calculateGallonsButton.Location = new System.Drawing.Point(422, 227);
            this.calculateGallonsButton.Name = "calculateGallonsButton";
            this.calculateGallonsButton.Size = new System.Drawing.Size(140, 46);
            this.calculateGallonsButton.TabIndex = 2;
            this.calculateGallonsButton.Text = "C&alculate";
            this.calculateGallonsButton.UseVisualStyleBackColor = false;
            this.calculateGallonsButton.Click += new System.EventHandler(this.calculateGallonsButton_Click);
            // 
            // gallonOfPaintLabel
            // 
            this.gallonOfPaintLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.gallonOfPaintLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallonOfPaintLabel.Location = new System.Drawing.Point(131, 323);
            this.gallonOfPaintLabel.Name = "gallonOfPaintLabel";
            this.gallonOfPaintLabel.Size = new System.Drawing.Size(139, 59);
            this.gallonOfPaintLabel.TabIndex = 7;
            this.gallonOfPaintLabel.Text = "Gallons of Paint Needed";
            this.gallonOfPaintLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costOfPaintLabel
            // 
            this.costOfPaintLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.costOfPaintLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costOfPaintLabel.Location = new System.Drawing.Point(708, 323);
            this.costOfPaintLabel.Name = "costOfPaintLabel";
            this.costOfPaintLabel.Size = new System.Drawing.Size(139, 59);
            this.costOfPaintLabel.TabIndex = 11;
            this.costOfPaintLabel.Text = "Cost of Paint";
            this.costOfPaintLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursOfLaborLabel
            // 
            this.hoursOfLaborLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.hoursOfLaborLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hoursOfLaborLabel.Location = new System.Drawing.Point(423, 323);
            this.hoursOfLaborLabel.Name = "hoursOfLaborLabel";
            this.hoursOfLaborLabel.Size = new System.Drawing.Size(139, 59);
            this.hoursOfLaborLabel.TabIndex = 9;
            this.hoursOfLaborLabel.Text = "Hours of Labor";
            this.hoursOfLaborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costOfLaborLabel
            // 
            this.costOfLaborLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.costOfLaborLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costOfLaborLabel.Location = new System.Drawing.Point(272, 485);
            this.costOfLaborLabel.Name = "costOfLaborLabel";
            this.costOfLaborLabel.Size = new System.Drawing.Size(139, 59);
            this.costOfLaborLabel.TabIndex = 13;
            this.costOfLaborLabel.Text = "Cost of Labor";
            this.costOfLaborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCostLabel.Location = new System.Drawing.Point(568, 485);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(139, 59);
            this.totalCostLabel.TabIndex = 15;
            this.totalCostLabel.Text = "Total Cost of Job";
            this.totalCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paintJobEstimatorLabel
            // 
            this.paintJobEstimatorLabel.AutoSize = true;
            this.paintJobEstimatorLabel.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.paintJobEstimatorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paintJobEstimatorLabel.ForeColor = System.Drawing.Color.DarkViolet;
            this.paintJobEstimatorLabel.Location = new System.Drawing.Point(307, 33);
            this.paintJobEstimatorLabel.Name = "paintJobEstimatorLabel";
            this.paintJobEstimatorLabel.Size = new System.Drawing.Size(370, 44);
            this.paintJobEstimatorLabel.TabIndex = 10;
            this.paintJobEstimatorLabel.Text = "Paint Job Estimator";
            this.paintJobEstimatorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gallonOfPaintRequiredLabel
            // 
            this.gallonOfPaintRequiredLabel.BackColor = System.Drawing.SystemColors.WindowText;
            this.gallonOfPaintRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gallonOfPaintRequiredLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.gallonOfPaintRequiredLabel.Location = new System.Drawing.Point(135, 403);
            this.gallonOfPaintRequiredLabel.Name = "gallonOfPaintRequiredLabel";
            this.gallonOfPaintRequiredLabel.Size = new System.Drawing.Size(135, 31);
            this.gallonOfPaintRequiredLabel.TabIndex = 8;
            this.gallonOfPaintRequiredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursOfLaborRequiredLabel
            // 
            this.hoursOfLaborRequiredLabel.BackColor = System.Drawing.SystemColors.WindowText;
            this.hoursOfLaborRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hoursOfLaborRequiredLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.hoursOfLaborRequiredLabel.Location = new System.Drawing.Point(427, 403);
            this.hoursOfLaborRequiredLabel.Name = "hoursOfLaborRequiredLabel";
            this.hoursOfLaborRequiredLabel.Size = new System.Drawing.Size(135, 31);
            this.hoursOfLaborRequiredLabel.TabIndex = 10;
            this.hoursOfLaborRequiredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costOfPaintRequiredLabel
            // 
            this.costOfPaintRequiredLabel.BackColor = System.Drawing.SystemColors.WindowText;
            this.costOfPaintRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costOfPaintRequiredLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.costOfPaintRequiredLabel.Location = new System.Drawing.Point(712, 403);
            this.costOfPaintRequiredLabel.Name = "costOfPaintRequiredLabel";
            this.costOfPaintRequiredLabel.Size = new System.Drawing.Size(135, 31);
            this.costOfPaintRequiredLabel.TabIndex = 12;
            this.costOfPaintRequiredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // costOfLaborRequiredLabel
            // 
            this.costOfLaborRequiredLabel.BackColor = System.Drawing.SystemColors.WindowText;
            this.costOfLaborRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.costOfLaborRequiredLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.costOfLaborRequiredLabel.Location = new System.Drawing.Point(276, 562);
            this.costOfLaborRequiredLabel.Name = "costOfLaborRequiredLabel";
            this.costOfLaborRequiredLabel.Size = new System.Drawing.Size(135, 31);
            this.costOfLaborRequiredLabel.TabIndex = 14;
            this.costOfLaborRequiredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostOfJobLabel
            // 
            this.totalCostOfJobLabel.BackColor = System.Drawing.SystemColors.WindowText;
            this.totalCostOfJobLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalCostOfJobLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalCostOfJobLabel.Location = new System.Drawing.Point(565, 562);
            this.totalCostOfJobLabel.Name = "totalCostOfJobLabel";
            this.totalCostOfJobLabel.Size = new System.Drawing.Size(135, 31);
            this.totalCostOfJobLabel.TabIndex = 16;
            this.totalCostOfJobLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.clearButton.Location = new System.Drawing.Point(315, 656);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(140, 46);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "&Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.Highlight;
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.exitButton.Location = new System.Drawing.Point(537, 656);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(140, 46);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // paintJobEstimator
            // 
            this.AcceptButton = this.calculateGallonsButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(953, 734);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.totalCostOfJobLabel);
            this.Controls.Add(this.costOfLaborRequiredLabel);
            this.Controls.Add(this.costOfPaintRequiredLabel);
            this.Controls.Add(this.hoursOfLaborRequiredLabel);
            this.Controls.Add(this.gallonOfPaintRequiredLabel);
            this.Controls.Add(this.paintJobEstimatorLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.costOfLaborLabel);
            this.Controls.Add(this.hoursOfLaborLabel);
            this.Controls.Add(this.costOfPaintLabel);
            this.Controls.Add(this.gallonOfPaintLabel);
            this.Controls.Add(this.calculateGallonsButton);
            this.Controls.Add(this.costGallonTextBox);
            this.Controls.Add(this.squareFootageTextBox);
            this.Controls.Add(this.costGallonPromptLabel);
            this.Controls.Add(this.squareFootagePromptLabel);
            this.Name = "paintJobEstimator";
            this.Text = "Paint Job Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label squareFootagePromptLabel;
        private System.Windows.Forms.Label costGallonPromptLabel;
        private System.Windows.Forms.TextBox squareFootageTextBox;
        private System.Windows.Forms.TextBox costGallonTextBox;
        private System.Windows.Forms.Button calculateGallonsButton;
        private System.Windows.Forms.Label gallonOfPaintLabel;
        private System.Windows.Forms.Label costOfPaintLabel;
        private System.Windows.Forms.Label hoursOfLaborLabel;
        private System.Windows.Forms.Label costOfLaborLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label paintJobEstimatorLabel;
        private System.Windows.Forms.Label gallonOfPaintRequiredLabel;
        private System.Windows.Forms.Label hoursOfLaborRequiredLabel;
        private System.Windows.Forms.Label costOfPaintRequiredLabel;
        private System.Windows.Forms.Label costOfLaborRequiredLabel;
        private System.Windows.Forms.Label totalCostOfJobLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

