﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project1
{ /* Jelecia Milton
    
   * COP2551
  
   * 8/29/2021
   
   * This form allows the user to click a card. When they choose their card,
   the name of the card is shown in the label box.*/

    public partial class cardIdentifier : Form
    {
        public cardIdentifier()
        {
            InitializeComponent();
        }

        private void sevenOfDiamonds_Click(object sender, EventArgs e)
        {
            //Click event handler to show Seven of Diamonds.
            cardChosenLabel.Text = "Seven of Diamonds";
        }

        private void queenOfClubs_Click(object sender, EventArgs e)
        {
            //Click event handler to show Queen of Clubs.
            cardChosenLabel.Text = "Queen of Clubs";
        }

        private void redJoker_Click(object sender, EventArgs e)
        {
            //Click event handler to show Red Joker.
            cardChosenLabel.Text = "Red Joker";
        }

        private void eightOfSpades_Click(object sender, EventArgs e)
        {
            //Click event handler to show Eight of Spades.
            cardChosenLabel.Text = "Eight of Spades";
        }

        private void aceOfHearts_Click(object sender, EventArgs e)
        {
            //Click event handler to show Ace of Hearts.
            cardChosenLabel.Text = "Ace of Hearts";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the Card Identifier.
            this.Close();
        }
    }
}
