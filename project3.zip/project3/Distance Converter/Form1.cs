﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Distance_Converter
{
    public partial class distanceConverter : Form
    {
        public distanceConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Variables
                double inches;
                double yards;
                double feet;
                double userInput;


                //Constants
                const double SAME_UNIT = 1.00;
                const double FEET_TO_YARDS = 0.333333;
                const double YARDS_TO_FEET = 3.00;
                const double INCHES_TO_FEET = 0.0833333;
                const double FEET_TO_INCHES = 12.00;
                const double INCHES_TO_YARDS = 0.0277778;
                const double YARDS_TO_INCHES = 36.00;

                //Parses the user's input
                userInput = double.Parse(enterTextBox.Text);

                //To hold the units from and the units to
                string unitsFrom;
                string unitsTo;

                if (fromListBox.SelectedIndex != -1)
                {
                    //Get the user's input
                    unitsFrom = fromListBox.SelectedItem.ToString();

                    switch(unitsFrom)
                    {
                        //Does the case and switch to convert
                        //inches to inches, feet and yards
                        case "Inches":
                            if (toListBox.SelectedIndex != -1)
                            {
                                unitsTo = toListBox.SelectedItem.ToString();

                                //Determine the conversions
                                switch (unitsTo)
                                {
                                    case "Inches":
                                        inches = userInput * SAME_UNIT;
                                        this.conversionLabel.Text = inches.ToString();
                                        break;

                                    case "Feet":
                                        feet = userInput * INCHES_TO_FEET;
                                        this.conversionLabel.Text = feet.ToString();
                                        break;

                                    case "Yards":
                                        yards = userInput * INCHES_TO_YARDS;
                                        this.conversionLabel.Text = yards.ToString();
                                        break;
                                }
                            }
                            else
                            {
                                //If user doesn't select a unit.
                                MessageBox.Show("Please select a unit.");
                            }
                            break;

                        //Does the case and switch to convert
                        //feet to feet, inches and yards
                        case "Feet":
                            if (toListBox.SelectedIndex != -1)
                            {
                                unitsTo = toListBox.SelectedItem.ToString();

                                switch (unitsTo)
                                {
                                    case "Feet":
                                        feet = userInput * SAME_UNIT;
                                        this.conversionLabel.Text = feet.ToString();
                                        break;

                                    case "Inches":
                                        inches = userInput * FEET_TO_INCHES;
                                        this.conversionLabel.Text = inches.ToString();
                                        break;

                                    case "Yards":
                                        yards = userInput * FEET_TO_YARDS;
                                        this.conversionLabel.Text = yards.ToString();
                                        break;
                                }
                            }
                            else
                            {
                                //If user doesn't select a unit.
                                MessageBox.Show("Please select a unit.");
                            }
                            break;

                        //Does the case and switch to convert
                        //yards to yards, inches and feet
                        case "Yards":
                            if (toListBox.SelectedIndex != -1)
                            {
                                unitsTo = toListBox.SelectedItem.ToString();

                                switch (unitsTo)
                                {
                                    case "Yards":
                                        yards = userInput * SAME_UNIT;
                                        this.conversionLabel.Text = yards.ToString();
                                        break;

                                    case "Inches":
                                        inches = userInput * YARDS_TO_INCHES;
                                        this.conversionLabel.Text = inches.ToString();
                                        break;

                                    case "Feet":
                                        feet = userInput * YARDS_TO_FEET;
                                        this.conversionLabel.Text = feet.ToString();
                                        break;
                                }
                            }
                            else
                            {
                                //If user doesn't select a unit.
                                MessageBox.Show("Please select a unit.");
                            }
                            break;
                    }
                }
                else
                {
                    //If no input is given
                    MessageBox.Show("Please select a unit.");
                }
            }
            catch (Exception ex)
            {
                //Display error box
                MessageBox.Show("Invalid data was entered.");
            }

        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all labels and textboxes with alt+l
            enterTextBox.Text = "";
            conversionLabel.Text = "";
            fromListBox.Text = "";
            toListBox.Text = "";
            
            //Return focus to the user input box
            enterTextBox.Focus();
        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            //Allows the user to close the program with alt+x
            this.Close();
        }
    }
}
